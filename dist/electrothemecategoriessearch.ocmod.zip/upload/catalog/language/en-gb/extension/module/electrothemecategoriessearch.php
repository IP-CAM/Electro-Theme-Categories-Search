<?php 
/** 
 * 
 * electrothemecategoriessearch.php
 * 
 * Language file for front page.
 * 
*/
$_['heading_title']     = 'Electro Theme - Categories Search';
